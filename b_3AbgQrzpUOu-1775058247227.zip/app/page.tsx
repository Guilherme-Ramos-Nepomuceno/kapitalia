"use client"

import { useState, useRef, useEffect } from "react"
import { QueryClient, QueryClientProvider, useQuery, useMutation } from "@tanstack/react-query"
import { z } from "zod"
import { useAppStore } from "@/lib/store"
import {
  Flame,
  Trophy,
  Zap,
  Lock,
  ChevronRight,
  ChevronLeft,
  Play,
  Pause,
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  CheckCircle2,
  XCircle,
  Sparkles,
  Target,
  TrendingUp,
  CreditCard,
  PiggyBank,
  Wallet,
  Crown,
  Home,
  Video,
  Map,
  Calculator,
  DollarSign,
  Percent,
  BarChart3,
  Building2,
  Coins,
  ArrowUpRight,
  ArrowDownRight,
  ChevronDown,
  ChevronUp,
  Star,
  Volume2,
  VolumeX,
  User,
  Mail,
  Eye,
  EyeOff,
  LogOut,
  Settings,
  Edit3,
  Award,
  Clock,
  Calendar,
  Sun,
  Moon,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

// ============================================
// MODEL: Zod Schemas
// ============================================

const UserSchema = z.object({
  id: z.string(),
  name: z.string(),
  avatar: z.string().url().optional(),
  level: z.number().min(1),
  xp: z.number().min(0),
  xpToNextLevel: z.number().min(1),
  streak: z.number().min(0),
  isPro: z.boolean(),
  totalCoins: z.number().min(0),
})

const OnboardingSchema = z.object({
  name: z.string().min(2, "Nome muito curto"),
  age: z.enum(["16-18", "19-21", "22-24", "25+"]),
  goal: z.enum(["poupar", "investir", "sair_dividas", "independencia"]),
  experience: z.enum(["nenhuma", "basica", "intermediaria", "avancada"]),
})

const LessonSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  duration: z.string(),
  xpReward: z.number(),
  isCompleted: z.boolean(),
  isLocked: z.boolean(),
  isPro: z.boolean(),
  icon: z.string(),
  category: z.string(),
})

const TrailSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  icon: z.string(),
  color: z.string(),
  isPro: z.boolean(),
  totalLessons: z.number(),
  completedLessons: z.number(),
  lessons: z.array(LessonSchema),
})

const VideoSchema = z.object({
  id: z.string(),
  title: z.string(),
  author: z.string(),
  authorAvatar: z.string(),
  thumbnail: z.string(),
  duration: z.string(),
  likes: z.number(),
  comments: z.number(),
  category: z.string(),
  isPro: z.boolean(),
})

const QuizQuestionSchema = z.object({
  id: z.string(),
  question: z.string(),
  options: z.array(z.string()),
  correctIndex: z.number(),
})

const DashboardDataSchema = z.object({
  user: UserSchema,
  lessons: z.array(LessonSchema),
  currentLesson: LessonSchema.nullable(),
  weeklyProgress: z.number(),
  trails: z.array(TrailSchema),
  videos: z.array(VideoSchema),
})

// Types
type User = z.infer<typeof UserSchema>
type OnboardingData = z.infer<typeof OnboardingSchema>
type Lesson = z.infer<typeof LessonSchema>
type Trail = z.infer<typeof TrailSchema>
type VideoItem = z.infer<typeof VideoSchema>
type QuizQuestion = z.infer<typeof QuizQuestionSchema>
type DashboardData = z.infer<typeof DashboardDataSchema>

// ============================================
// MODEL: Mock Data
// ============================================

const mockTrails: Trail[] = [
  {
    id: "trail-1",
    title: "Fundamentos Financeiros",
    description: "Aprenda o basico sobre dinheiro e orcamento",
    icon: "Wallet",
    color: "from-emerald-500 to-teal-600",
    isPro: false,
    totalLessons: 5,
    completedLessons: 3,
    lessons: [
      { id: "t1-1", title: "O que e dinheiro?", description: "Entenda o valor do dinheiro", duration: "3 min", xpReward: 30, isCompleted: true, isLocked: false, isPro: false, icon: "Coins", category: "Fundamentos" },
      { id: "t1-2", title: "Receitas vs Despesas", description: "Diferenca entre ganhos e gastos", duration: "4 min", xpReward: 40, isCompleted: true, isLocked: false, isPro: false, icon: "BarChart3", category: "Fundamentos" },
      { id: "t1-3", title: "Orcamento 50-30-20", description: "A regra de ouro do orcamento", duration: "5 min", xpReward: 50, isCompleted: true, isLocked: false, isPro: false, icon: "PiggyBank", category: "Fundamentos" },
      { id: "t1-4", title: "Metas Financeiras", description: "Como definir e alcancar metas", duration: "4 min", xpReward: 45, isCompleted: false, isLocked: false, isPro: false, icon: "Target", category: "Fundamentos" },
      { id: "t1-5", title: "Reserva de Emergencia", description: "Sua rede de seguranca financeira", duration: "5 min", xpReward: 55, isCompleted: false, isLocked: true, isPro: false, icon: "Shield", category: "Fundamentos" },
    ],
  },
  {
    id: "trail-2",
    title: "Credito Inteligente",
    description: "Domine o cartao de credito sem cair em armadilhas",
    icon: "CreditCard",
    color: "from-purple-500 to-indigo-600",
    isPro: false,
    totalLessons: 4,
    completedLessons: 1,
    lessons: [
      { id: "t2-1", title: "Como funciona o cartao", description: "Entenda o ciclo da fatura", duration: "4 min", xpReward: 40, isCompleted: true, isLocked: false, isPro: false, icon: "CreditCard", category: "Credito" },
      { id: "t2-2", title: "Juros do Rotativo", description: "A armadilha mais perigosa", duration: "5 min", xpReward: 50, isCompleted: false, isLocked: false, isPro: false, icon: "Percent", category: "Credito" },
      { id: "t2-3", title: "Score de Credito", description: "Aumente seu score", duration: "4 min", xpReward: 45, isCompleted: false, isLocked: true, isPro: false, icon: "TrendingUp", category: "Credito" },
      { id: "t2-4", title: "Cashback e Beneficios", description: "Ganhe com seu cartao", duration: "3 min", xpReward: 35, isCompleted: false, isLocked: true, isPro: false, icon: "DollarSign", category: "Credito" },
    ],
  },
  {
    id: "trail-3",
    title: "Investimentos Iniciantes",
    description: "Seus primeiros passos no mundo dos investimentos",
    icon: "TrendingUp",
    color: "from-blue-500 to-cyan-600",
    isPro: false,
    totalLessons: 5,
    completedLessons: 0,
    lessons: [
      { id: "t3-1", title: "Por que investir?", description: "O poder dos juros compostos", duration: "4 min", xpReward: 40, isCompleted: false, isLocked: false, isPro: false, icon: "Sparkles", category: "Investimentos" },
      { id: "t3-2", title: "Tesouro Direto", description: "O investimento mais seguro", duration: "6 min", xpReward: 60, isCompleted: false, isLocked: true, isPro: false, icon: "Building2", category: "Investimentos" },
      { id: "t3-3", title: "CDB e Renda Fixa", description: "Investindo com seguranca", duration: "5 min", xpReward: 50, isCompleted: false, isLocked: true, isPro: false, icon: "Coins", category: "Investimentos" },
      { id: "t3-4", title: "Fundos de Investimento", description: "Diversificando com praticidade", duration: "5 min", xpReward: 55, isCompleted: false, isLocked: true, isPro: false, icon: "BarChart3", category: "Investimentos" },
      { id: "t3-5", title: "Criando sua Carteira", description: "Monte sua primeira carteira", duration: "6 min", xpReward: 65, isCompleted: false, isLocked: true, isPro: false, icon: "Wallet", category: "Investimentos" },
    ],
  },
  {
    id: "trail-4",
    title: "Acoes e Bolsa",
    description: "Aprenda a investir na bolsa de valores",
    icon: "BarChart3",
    color: "from-amber-400 to-yellow-600",
    isPro: true,
    totalLessons: 6,
    completedLessons: 0,
    lessons: [
      { id: "t4-1", title: "O que sao Acoes?", description: "Entenda o mercado de acoes", duration: "5 min", xpReward: 50, isCompleted: false, isLocked: false, isPro: true, icon: "BarChart3", category: "Acoes" },
      { id: "t4-2", title: "Analise Fundamentalista", description: "Avalie empresas como um pro", duration: "7 min", xpReward: 70, isCompleted: false, isLocked: true, isPro: true, icon: "Target", category: "Acoes" },
      { id: "t4-3", title: "Analise Tecnica Basica", description: "Graficos e tendencias", duration: "6 min", xpReward: 60, isCompleted: false, isLocked: true, isPro: true, icon: "TrendingUp", category: "Acoes" },
      { id: "t4-4", title: "Dividendos", description: "Renda passiva com acoes", duration: "5 min", xpReward: 55, isCompleted: false, isLocked: true, isPro: true, icon: "DollarSign", category: "Acoes" },
      { id: "t4-5", title: "FIIs - Fundos Imobiliarios", description: "Invista em imoveis", duration: "6 min", xpReward: 60, isCompleted: false, isLocked: true, isPro: true, icon: "Building2", category: "Acoes" },
      { id: "t4-6", title: "Montando Carteira de Acoes", description: "Estrategia completa", duration: "8 min", xpReward: 80, isCompleted: false, isLocked: true, isPro: true, icon: "Wallet", category: "Acoes" },
    ],
  },
  {
    id: "trail-5",
    title: "Cripto para Iniciantes",
    description: "Entenda o mundo das criptomoedas",
    icon: "Coins",
    color: "from-orange-500 to-red-600",
    isPro: true,
    totalLessons: 4,
    completedLessons: 0,
    lessons: [
      { id: "t5-1", title: "O que e Bitcoin?", description: "A primeira criptomoeda", duration: "5 min", xpReward: 50, isCompleted: false, isLocked: false, isPro: true, icon: "Coins", category: "Cripto" },
      { id: "t5-2", title: "Blockchain Explicado", description: "A tecnologia por tras", duration: "6 min", xpReward: 60, isCompleted: false, isLocked: true, isPro: true, icon: "Building2", category: "Cripto" },
      { id: "t5-3", title: "Ethereum e Altcoins", description: "Alem do Bitcoin", duration: "5 min", xpReward: 55, isCompleted: false, isLocked: true, isPro: true, icon: "Sparkles", category: "Cripto" },
      { id: "t5-4", title: "Como Comprar Cripto", description: "Passo a passo pratico", duration: "4 min", xpReward: 45, isCompleted: false, isLocked: true, isPro: true, icon: "Wallet", category: "Cripto" },
    ],
  },
]

const mockVideos: VideoItem[] = [
  { id: "v1", title: "3 erros que todo iniciante comete com cartao de credito", author: "Kapitalia", authorAvatar: "K", thumbnail: "", duration: "2:45", likes: 15420, comments: 342, category: "Credito", isPro: false },
  { id: "v2", title: "Como economizei R$500 em um mes fazendo isso", author: "Kapitalia", authorAvatar: "K", thumbnail: "", duration: "3:12", likes: 28930, comments: 567, category: "Economia", isPro: false },
  { id: "v3", title: "Tesouro Direto explicado em 60 segundos", author: "Kapitalia", authorAvatar: "K", thumbnail: "", duration: "1:02", likes: 45200, comments: 890, category: "Investimentos", isPro: false },
  { id: "v4", title: "A regra 50-30-20 que mudou minha vida", author: "Kapitalia", authorAvatar: "K", thumbnail: "", duration: "2:30", likes: 32100, comments: 421, category: "Orcamento", isPro: false },
  { id: "v5", title: "Score de credito: como subir rapido", author: "Kapitalia", authorAvatar: "K", thumbnail: "", duration: "3:45", likes: 19800, comments: 298, category: "Credito", isPro: false },
  { id: "v6", title: "Estrategia de dividendos para iniciantes", author: "Kapitalia", authorAvatar: "K", thumbnail: "", duration: "4:20", likes: 12300, comments: 234, category: "Investimentos", isPro: true },
  { id: "v7", title: "Bitcoin: comprar ou nao comprar?", author: "Kapitalia", authorAvatar: "K", thumbnail: "", duration: "3:55", likes: 38400, comments: 1205, category: "Cripto", isPro: true },
]

const mockQuizQuestions: QuizQuestion[] = [
  { id: "q1", question: "Qual e o prazo medio para pagar a fatura do cartao sem juros?", options: ["5 dias", "10 dias", "30 dias", "40 dias"], correctIndex: 2 },
  { id: "q2", question: "O que acontece se voce pagar apenas o minimo da fatura?", options: ["Nada, esta tudo certo", "Voce entra no rotativo e paga juros altos", "Seu limite aumenta", "Voce ganha cashback"], correctIndex: 1 },
  { id: "q3", question: "Qual a melhor estrategia para usar o cartao de credito?", options: ["Pagar sempre o minimo", "Parcelar tudo em 12x", "Pagar a fatura total todo mes", "Usar o limite todo"], correctIndex: 2 },
]

const fetchDashboardData = (): Promise<DashboardData> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        user: { id: "user-1", name: "Joao", level: 3, xp: 280, xpToNextLevel: 500, streak: 7, isPro: false, totalCoins: 1250 },
        lessons: mockTrails[0].lessons,
        currentLesson: mockTrails[0].lessons[3],
        weeklyProgress: 65,
        trails: mockTrails,
        videos: mockVideos,
      })
    }, 800)
  })
}

const submitOnboarding = (data: OnboardingData): Promise<{ success: boolean }> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const result = OnboardingSchema.safeParse(data)
      if (result.success) resolve({ success: true })
      else reject(new Error("Dados invalidos"))
    }, 800)
  })
}

// ============================================
// VIEWMODELS
// ============================================

function useDashboardViewModel() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["dashboard"],
    queryFn: fetchDashboardData,
    staleTime: 5 * 60 * 1000,
  })
  return { data, isLoading, error, refetch }
}

function useOnboardingViewModel(onSuccess: () => void) {
  const mutation = useMutation({
    mutationFn: submitOnboarding,
    onSuccess: () => onSuccess(),
  })
  const validateAndSubmit = (data: OnboardingData) => {
    const result = OnboardingSchema.safeParse(data)
    if (result.success) mutation.mutate(result.data)
  }
  return { submit: validateAndSubmit, isLoading: mutation.isPending, isError: mutation.isError, error: mutation.error }
}

// ============================================
// VIEWS: Skeletons
// ============================================

function DashboardSkeleton() {
  return (
    <div className="space-y-6 p-4 pb-24">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Skeleton className="h-12 w-12 rounded-full bg-slate-800" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-24 bg-slate-800" />
            <Skeleton className="h-3 w-16 bg-slate-800" />
          </div>
        </div>
        <Skeleton className="h-10 w-20 rounded-2xl bg-slate-800" />
      </div>
      <div className="grid grid-cols-3 gap-3">
        {[1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-2xl bg-slate-800" />)}
      </div>
      <Skeleton className="h-32 rounded-3xl bg-slate-800" />
      <div className="space-y-3">
        {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-2xl bg-slate-800" />)}
      </div>
    </div>
  )
}

// ============================================
// VIEWS: Onboarding
// ============================================

interface OnboardingQuestion {
  id: keyof OnboardingData
  question: string
  options: { value: string; label: string; emoji: string }[]
}

const onboardingQuestions: OnboardingQuestion[] = [
  { id: "name", question: "Como posso te chamar?", options: [] },
  { id: "age", question: "Qual sua faixa etaria?", options: [{ value: "16-18", label: "16-18 anos", emoji: "🎓" }, { value: "19-21", label: "19-21 anos", emoji: "🎯" }, { value: "22-24", label: "22-24 anos", emoji: "💼" }, { value: "25+", label: "25+ anos", emoji: "🚀" }] },
  { id: "goal", question: "Qual seu maior objetivo financeiro?", options: [{ value: "poupar", label: "Comecar a poupar", emoji: "💰" }, { value: "investir", label: "Aprender a investir", emoji: "📈" }, { value: "sair_dividas", label: "Sair das dividas", emoji: "🎯" }, { value: "independencia", label: "Independencia financeira", emoji: "🏆" }] },
  { id: "experience", question: "Qual seu nivel de experiencia com financas?", options: [{ value: "nenhuma", label: "Sou iniciante total", emoji: "🌱" }, { value: "basica", label: "Sei o basico", emoji: "📚" }, { value: "intermediaria", label: "Tenho alguma experiencia", emoji: "⚡" }, { value: "avancada", label: "Ja mando bem", emoji: "🔥" }] },
]

function OnboardingView({ onComplete, onSubmit }: { onComplete: () => void; onSubmit?: (data: OnboardingData) => void }) {
  const [currentStep, setCurrentStep] = useState(0)
  const [answers, setAnswers] = useState<Partial<OnboardingData>>({})
  const [nameInput, setNameInput] = useState("")
  const { submit, isLoading } = useOnboardingViewModel(() => {
    if (onSubmit && answers.name && answers.age && answers.goal && answers.experience) {
      onSubmit(answers as OnboardingData)
    }
    onComplete()
  })
  const currentQuestion = onboardingQuestions[currentStep]
  const progress = ((currentStep + 1) / onboardingQuestions.length) * 100

  const handleNameSubmit = () => {
    if (nameInput.length >= 2) {
      setAnswers({ ...answers, name: nameInput })
      setCurrentStep(currentStep + 1)
    }
  }

  const handleOptionSelect = (value: string) => {
    const newAnswers = { ...answers, [currentQuestion.id]: value }
    setAnswers(newAnswers)
    if (currentStep < onboardingQuestions.length - 1) {
      setTimeout(() => setCurrentStep(currentStep + 1), 300)
    } else {
      submit(newAnswers as OnboardingData)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-slate-950 px-4 py-8">
      <div className="mb-8">
        <div className="mb-2 flex items-center justify-between text-sm text-slate-400">
          <span>{currentStep + 1} de {onboardingQuestions.length}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-slate-800">
          <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>
      <div className="flex flex-1 flex-col items-center justify-center">
        <h1 className="mb-8 text-center text-2xl font-bold text-white">{currentQuestion.question}</h1>
        {currentQuestion.id === "name" ? (
          <div className="w-full max-w-sm space-y-4">
            <input type="text" value={nameInput} onChange={(e) => setNameInput(e.target.value)} placeholder="Seu nome" className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-6 py-4 text-center text-lg text-white placeholder-slate-500 outline-none transition-all focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20" autoFocus />
            <Button onClick={handleNameSubmit} disabled={nameInput.length < 2} className="h-14 w-full rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-lg font-bold text-white transition-all hover:scale-[1.02] disabled:opacity-50">Continuar</Button>
          </div>
        ) : (
          <div className="w-full max-w-sm space-y-3">
            {currentQuestion.options.map((option) => (
              <button key={option.value} onClick={() => handleOptionSelect(option.value)} disabled={isLoading} className="flex w-full items-center gap-4 rounded-2xl border border-slate-700 bg-slate-900 p-4 text-left transition-all duration-200 hover:scale-[1.02] hover:border-emerald-500 hover:bg-slate-800 active:scale-[0.98] disabled:opacity-50">
                <span className="text-2xl">{option.emoji}</span>
                <span className="text-lg font-medium text-white">{option.label}</span>
              </button>
            ))}
          </div>
        )}
      </div>
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-4">
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-emerald-500 border-t-transparent" />
            <p className="text-lg font-medium text-white">Preparando sua jornada...</p>
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================
// VIEWS: Bottom Navigation
// ============================================

type TabType = "home" | "videos" | "trails" | "tools" | "profile"

function BottomNav({ activeTab, onTabChange }: { activeTab: TabType; onTabChange: (tab: TabType) => void }) {
  const tabs = [
    { id: "home" as TabType, icon: Home, label: "Inicio" },
    { id: "videos" as TabType, icon: Video, label: "Videos" },
    { id: "trails" as TabType, icon: Map, label: "Trilhas" },
    { id: "tools" as TabType, icon: Calculator, label: "Ferramentas" },
    { id: "profile" as TabType, icon: User, label: "Perfil" },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-slate-800 bg-slate-950/95 backdrop-blur-lg">
      <div className="flex items-center justify-around py-2">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const isActive = activeTab === tab.id
          return (
            <button key={tab.id} onClick={() => onTabChange(tab.id)} className={`flex flex-col items-center gap-1 px-4 py-2 transition-all duration-200 ${isActive ? "scale-105" : "opacity-60 hover:opacity-100"}`}>
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl transition-all ${isActive ? "bg-emerald-500/20" : ""}`}>
                <Icon className={`h-6 w-6 ${isActive ? "text-emerald-400" : "text-slate-400"}`} />
              </div>
              <span className={`text-xs font-medium ${isActive ? "text-emerald-400" : "text-slate-400"}`}>{tab.label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}

// ============================================
// VIEWS: Home Dashboard
// ============================================

function StatCard({ icon: Icon, value, label, gradient }: { icon: React.ElementType; value: string | number; label: string; gradient: string }) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900 p-4 transition-all duration-200 hover:scale-105 hover:border-slate-700">
      <div className={`mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${gradient}`}>
        <Icon className="h-5 w-5 text-white" />
      </div>
      <p className="text-xl font-bold text-white">{value}</p>
      <p className="text-sm text-slate-400">{label}</p>
    </div>
  )
}

function HomeView({ data, onStartLesson, onProClick }: { data: DashboardData; onStartLesson: (lesson: Lesson) => void; onProClick: () => void }) {
  const xpProgress = (data.user.xp / data.user.xpToNextLevel) * 100

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-6 pb-28">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 text-lg font-bold text-white">
            {data.user.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <h1 className="text-lg font-bold text-white">Ola, {data.user.name}!</h1>
            <p className="text-sm text-slate-400">Nivel {data.user.level}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 rounded-2xl border border-orange-500/30 bg-orange-500/10 px-3 py-2">
          <Flame className="h-5 w-5 text-orange-500" />
          <span className="font-bold text-orange-500">{data.user.streak}</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="mb-6 grid grid-cols-3 gap-3">
        <StatCard icon={Zap} value={data.user.xp} label="XP Total" gradient="from-emerald-500 to-teal-500" />
        <StatCard icon={Trophy} value={data.user.level} label="Nivel" gradient="from-amber-400 to-yellow-600" />
        <StatCard icon={Coins} value={data.user.totalCoins} label="Moedas" gradient="from-purple-500 to-indigo-500" />
      </div>

      {/* XP Progress */}
      <div className="mb-6 rounded-3xl border border-slate-800 bg-slate-900 p-5">
        <div className="mb-3 flex items-center justify-between">
          <span className="text-sm font-medium text-slate-400">Progresso para Nivel {data.user.level + 1}</span>
          <span className="text-sm font-bold text-emerald-400">{data.user.xp}/{data.user.xpToNextLevel} XP</span>
        </div>
        <div className="h-3 overflow-hidden rounded-full bg-slate-800">
          <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-500" style={{ width: `${xpProgress}%` }} />
        </div>
      </div>

      {/* Streak Banner */}
      {data.user.streak >= 7 && (
        <div className="mb-6 flex items-center gap-4 rounded-3xl border border-orange-500/30 bg-gradient-to-r from-orange-500/10 to-red-500/10 p-4">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-red-500">
            <Flame className="h-8 w-8 text-white" />
          </div>
          <div>
            <p className="font-bold text-white">Sua ofensiva ta pegando fogo!</p>
            <p className="text-sm text-slate-400">{data.user.streak} dias seguidos estudando</p>
          </div>
        </div>
      )}

      {/* Continue Learning */}
      {data.currentLesson && (
        <div className="mb-6">
          <h2 className="mb-3 text-lg font-bold text-white">Continuar aprendendo</h2>
          <button onClick={() => onStartLesson(data.currentLesson!)} className="flex w-full items-center gap-4 rounded-3xl border border-emerald-500/30 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 p-5 transition-all duration-200 hover:scale-[1.02]">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-500">
              <Play className="h-7 w-7 text-white" fill="white" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold text-white">{data.currentLesson.title}</h3>
              <p className="text-sm text-slate-400">{data.currentLesson.description}</p>
            </div>
            <ChevronRight className="h-6 w-6 text-emerald-400" />
          </button>
        </div>
      )}

      {/* Recent Trails */}
      <div>
        <h2 className="mb-3 text-lg font-bold text-white">Suas trilhas</h2>
        <div className="space-y-3">
          {data.trails.slice(0, 3).map((trail) => (
            <div key={trail.id} className={`rounded-2xl border p-4 transition-all ${trail.isPro ? "border-amber-500/30 bg-amber-500/5" : "border-slate-800 bg-slate-900"}`}>
              <div className="flex items-center gap-4">
                <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${trail.color}`}>
                  {trail.isPro ? <Crown className="h-6 w-6 text-white" /> : <Map className="h-6 w-6 text-white" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-white">{trail.title}</h3>
                    {trail.isPro && <span className="rounded-full bg-gradient-to-r from-amber-400 to-yellow-600 px-2 py-0.5 text-xs font-bold text-slate-900">PRO</span>}
                  </div>
                  <p className="text-sm text-slate-400">{trail.completedLessons}/{trail.totalLessons} licoes</p>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold text-emerald-400">{Math.round((trail.completedLessons / trail.totalLessons) * 100)}%</span>
                </div>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-800">
                <div className={`h-full bg-gradient-to-r ${trail.color} transition-all`} style={{ width: `${(trail.completedLessons / trail.totalLessons) * 100}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ============================================
// VIEWS: Videos Feed (TikTok Style with Swipe)
// ============================================

function VideoFeed({ videos, onProClick }: { videos: VideoItem[]; onProClick: () => void }) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(true)
  const [isMuted, setIsMuted] = useState(false)
  const [touchStart, setTouchStart] = useState<number | null>(null)
  const [touchEnd, setTouchEnd] = useState<number | null>(null)
  const [isTransitioning, setIsTransitioning] = useState(false)

  // Zustand store for persisted video interactions
  const { 
    toggleLikeVideo, 
    toggleSaveVideo, 
    markVideoWatched,
    isVideoLiked, 
    isVideoSaved 
  } = useAppStore()

  const minSwipeDistance = 50

  const currentVideo = videos[currentIndex]

  // Mark video as watched when viewing
  useEffect(() => {
    if (currentVideo) {
      markVideoWatched(currentVideo.id)
    }
  }, [currentVideo, markVideoWatched])

  const handleNext = () => {
    if (currentIndex < videos.length - 1 && !isTransitioning) {
      setIsTransitioning(true)
      setCurrentIndex(currentIndex + 1)
      setTimeout(() => setIsTransitioning(false), 300)
    }
  }

  const handlePrev = () => {
    if (currentIndex > 0 && !isTransitioning) {
      setIsTransitioning(true)
      setCurrentIndex(currentIndex - 1)
      setTimeout(() => setIsTransitioning(false), 300)
    }
  }

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null)
    setTouchStart(e.targetTouches[0].clientY)
  }

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientY)
  }

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return
    const distance = touchStart - touchEnd
    const isUpSwipe = distance > minSwipeDistance
    const isDownSwipe = distance < -minSwipeDistance
    if (isUpSwipe) handleNext()
    if (isDownSwipe) handlePrev()
  }

  const toggleLike = (id: string) => {
    toggleLikeVideo(id)
  }

  const toggleSave = (id: string) => {
    toggleSaveVideo(id)
  }
  
  // Helper to check if video is liked/saved
  const likedVideos = { has: (id: string) => isVideoLiked(id) }
  const savedVideos = { has: (id: string) => isVideoSaved(id) }

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`
    return num.toString()
  }

  // Video color gradients based on category
  const getCategoryGradient = (category: string) => {
    const gradients: Record<string, string> = {
      "Credito": "from-purple-900 via-purple-800 to-indigo-900",
      "Economia": "from-emerald-900 via-teal-800 to-cyan-900",
      "Investimentos": "from-blue-900 via-blue-800 to-cyan-900",
      "Orcamento": "from-amber-900 via-orange-800 to-red-900",
      "Cripto": "from-orange-900 via-red-800 to-pink-900",
    }
    return gradients[category] || "from-slate-900 via-slate-800 to-slate-900"
  }

  return (
    <div 
      className="relative h-screen overflow-hidden bg-slate-950"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      {/* Videos Stack */}
      <div className="relative h-full">
        {videos.map((video, index) => {
          const offset = index - currentIndex
          const isVisible = Math.abs(offset) <= 1
          
          if (!isVisible) return null

          return (
            <div
              key={video.id}
              className={`absolute inset-0 transition-all duration-300 ease-out ${
                offset === 0 ? "translate-y-0 opacity-100" : 
                offset === 1 ? "translate-y-full opacity-50" : 
                offset === -1 ? "-translate-y-full opacity-50" : "hidden"
              }`}
            >
              {/* Video Background */}
              <div className={`absolute inset-0 bg-gradient-to-br ${getCategoryGradient(video.category)}`}>
                {/* Animated Background Pattern */}
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute left-1/4 top-1/4 h-64 w-64 animate-pulse rounded-full bg-white/20 blur-3xl" />
                  <div className="absolute bottom-1/4 right-1/4 h-48 w-48 animate-pulse rounded-full bg-white/10 blur-2xl" style={{ animationDelay: "1s" }} />
                </div>
                
                <div className="absolute inset-0 flex flex-col items-center justify-center p-8">
                  {/* Category Badge */}
                  <span className="mb-4 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-sm font-medium text-white backdrop-blur-sm">
                    {video.category}
                  </span>
                  
                  {/* Video Title */}
                  <h2 className="mb-6 max-w-xs text-center text-xl font-bold leading-tight text-white">{video.title}</h2>
                  
                  {/* Play/Pause Indicator */}
                  {index === currentIndex && (
                    <button 
                      onClick={() => setIsPlaying(!isPlaying)} 
                      className="flex h-20 w-20 items-center justify-center rounded-full bg-white/10 backdrop-blur-md transition-all hover:scale-110 hover:bg-white/20"
                    >
                      {isPlaying ? <Pause className="h-10 w-10 text-white" /> : <Play className="h-10 w-10 text-white" fill="white" />}
                    </button>
                  )}
                  
                  {/* Duration */}
                  <span className="mt-6 rounded-full bg-black/30 px-4 py-1.5 text-sm font-medium text-white backdrop-blur-sm">{video.duration}</span>
                  
                  {/* Pro Badge */}
                  {video.isPro && (
                    <button onClick={onProClick} className="mt-4 flex items-center gap-2 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 px-5 py-2 font-bold text-slate-900 shadow-lg shadow-amber-500/25 transition-all hover:scale-105">
                      <Crown className="h-4 w-4" />
                      <span>Conteudo PRO</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )
        })}

        {/* Progress Bar */}
        <div className="absolute bottom-20 left-0 right-0 px-4">
          <div className="h-1 overflow-hidden rounded-full bg-white/20">
            <div className="h-full bg-gradient-to-r from-emerald-400 to-teal-400 transition-all duration-1000" style={{ width: "45%" }} />
          </div>
        </div>

        {/* Side Actions */}
        <div className="absolute bottom-32 right-4 flex flex-col items-center gap-5">
          {/* Author Avatar */}
          <div className="relative mb-2">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 text-lg font-bold text-white ring-2 ring-white shadow-lg">
              {currentVideo.authorAvatar}
            </div>
            <button className="absolute -bottom-1 left-1/2 flex h-5 w-5 -translate-x-1/2 items-center justify-center rounded-full bg-emerald-500 text-xs font-bold text-white shadow-md">+</button>
          </div>

          {/* Like */}
          <button onClick={() => toggleLike(currentVideo.id)} className="flex flex-col items-center gap-1 transition-transform active:scale-90">
            <div className={`flex h-12 w-12 items-center justify-center rounded-full shadow-lg transition-colors ${likedVideos.has(currentVideo.id) ? "bg-red-500" : "bg-black/30 backdrop-blur-sm"}`}>
              <Heart className={`h-6 w-6 transition-all ${likedVideos.has(currentVideo.id) ? "scale-110 fill-white text-white" : "text-white"}`} />
            </div>
            <span className="text-xs font-medium text-white">{formatNumber(currentVideo.likes + (likedVideos.has(currentVideo.id) ? 1 : 0))}</span>
          </button>

          {/* Comments */}
          <button className="flex flex-col items-center gap-1 transition-transform active:scale-90">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-black/30 shadow-lg backdrop-blur-sm">
              <MessageCircle className="h-6 w-6 text-white" />
            </div>
            <span className="text-xs font-medium text-white">{formatNumber(currentVideo.comments)}</span>
          </button>

          {/* Save */}
          <button onClick={() => toggleSave(currentVideo.id)} className="flex flex-col items-center gap-1 transition-transform active:scale-90">
            <div className={`flex h-12 w-12 items-center justify-center rounded-full shadow-lg transition-colors ${savedVideos.has(currentVideo.id) ? "bg-emerald-500" : "bg-black/30 backdrop-blur-sm"}`}>
              <Bookmark className={`h-6 w-6 transition-all ${savedVideos.has(currentVideo.id) ? "fill-white text-white" : "text-white"}`} />
            </div>
            <span className="text-xs font-medium text-white">Salvar</span>
          </button>

          {/* Share */}
          <button className="flex flex-col items-center gap-1 transition-transform active:scale-90">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-black/30 shadow-lg backdrop-blur-sm">
              <Share2 className="h-6 w-6 text-white" />
            </div>
            <span className="text-xs font-medium text-white">Enviar</span>
          </button>

          {/* Mute */}
          <button onClick={() => setIsMuted(!isMuted)} className="flex flex-col items-center gap-1 transition-transform active:scale-90">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-black/30 shadow-lg backdrop-blur-sm">
              {isMuted ? <VolumeX className="h-5 w-5 text-white" /> : <Volume2 className="h-5 w-5 text-white" />}
            </div>
          </button>
        </div>

        {/* Navigation Indicators */}
        <div className="absolute left-4 top-4 flex items-center gap-3">
          <div className="rounded-full bg-black/30 px-3 py-1.5 text-sm font-medium text-white backdrop-blur-sm">
            {currentIndex + 1} / {videos.length}
          </div>
          {currentIndex > 0 && (
            <button onClick={handlePrev} className="rounded-full bg-black/30 p-2 backdrop-blur-sm transition-transform hover:scale-110">
              <ChevronUp className="h-5 w-5 text-white" />
            </button>
          )}
        </div>

        {/* Scroll Hint */}
        {currentIndex < videos.length - 1 && (
          <div className="absolute bottom-24 left-1/2 -translate-x-1/2 flex flex-col items-center">
            <button onClick={handleNext} className="animate-bounce rounded-full bg-black/30 p-2 backdrop-blur-sm">
              <ChevronDown className="h-6 w-6 text-white" />
            </button>
            <span className="mt-1 text-xs text-white/60">Deslize para mais</span>
          </div>
        )}

        {/* Video Dots Indicator */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-2">
          {videos.slice(0, 5).map((_, index) => (
            <button
              key={index}
              onClick={() => {
                if (!isTransitioning) {
                  setIsTransitioning(true)
                  setCurrentIndex(index)
                  setTimeout(() => setIsTransitioning(false), 300)
                }
              }}
              className={`h-2 w-2 rounded-full transition-all ${
                index === currentIndex ? "h-6 bg-white" : "bg-white/40"
              }`}
            />
          ))}
        </div>

        {/* Author Info */}
        <div className="absolute bottom-24 left-4 right-20">
          <p className="font-bold text-white drop-shadow-lg">@{currentVideo.author}</p>
          <p className="mt-1 line-clamp-2 text-sm text-white/80">{currentVideo.title}</p>
        </div>
      </div>
    </div>
  )
}

// ============================================
// VIEWS: Trails (Duolingo Style)
// ============================================

function TrailsView({ trails, onStartLesson, onProClick }: { trails: Trail[]; onStartLesson: (lesson: Lesson) => void; onProClick: () => void }) {
  const [selectedTrail, setSelectedTrail] = useState<Trail | null>(null)

  if (selectedTrail) {
    return (
      <TrailDetailView
        trail={selectedTrail}
        onBack={() => setSelectedTrail(null)}
        onStartLesson={onStartLesson}
        onProClick={onProClick}
      />
    )
  }

  const freeTrails = trails.filter((t) => !t.isPro)
  const proTrails = trails.filter((t) => t.isPro)

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-6 pb-28">
      <h1 className="mb-6 text-2xl font-bold text-white">Trilhas de Aprendizado</h1>

      {/* Free Trails */}
      <div className="mb-8">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
          <Sparkles className="h-5 w-5 text-emerald-400" />
          Trilhas Gratuitas
        </h2>
        <div className="relative">
          {/* Vertical Connection Line */}
          <div className="absolute left-7 top-8 bottom-8 w-1 rounded-full bg-gradient-to-b from-emerald-500/50 via-emerald-500/30 to-slate-700" />
          
          <div className="space-y-6">
            {freeTrails.map((trail, index) => {
              const progress = (trail.completedLessons / trail.totalLessons) * 100
              const isCompleted = progress === 100
              const isStarted = progress > 0
              
              return (
                <div key={trail.id} className="relative">
                  {/* Connection Node */}
                  <div className={`absolute left-5 top-1/2 z-10 flex h-5 w-5 -translate-y-1/2 items-center justify-center rounded-full border-4 ${
                    isCompleted ? "border-emerald-500 bg-emerald-500" : 
                    isStarted ? "border-emerald-500 bg-slate-950" : 
                    "border-slate-600 bg-slate-950"
                  }`}>
                    {isCompleted && <CheckCircle2 className="h-3 w-3 text-white" />}
                  </div>
                  
                  <button
                    onClick={() => setSelectedTrail(trail)}
                    className="ml-12 w-[calc(100%-3rem)] overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 p-4 text-left transition-all hover:scale-[1.02] hover:border-emerald-500/50 hover:bg-slate-800"
                  >
                    <div className="flex items-center gap-4">
                      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${trail.color}`}>
                        <Map className="h-6 w-6 text-white" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="truncate font-bold text-white">{trail.title}</h3>
                        <p className="truncate text-sm text-slate-400">{trail.description}</p>
                        <div className="mt-2 flex items-center gap-3">
                          <span className="text-xs text-slate-500">{trail.totalLessons} licoes</span>
                          <span className="text-xs font-medium text-emerald-400">{trail.completedLessons}/{trail.totalLessons}</span>
                        </div>
                      </div>
                      <div className="flex shrink-0 flex-col items-center">
                        <div className="relative h-11 w-11">
                          <svg className="h-11 w-11 -rotate-90">
                            <circle cx="22" cy="22" r="18" fill="none" stroke="#1e293b" strokeWidth="3" />
                            <circle cx="22" cy="22" r="18" fill="none" stroke={`url(#gradient-${trail.id})`} strokeWidth="3" strokeDasharray={`${progress * 1.13} 113`} strokeLinecap="round" />
                            <defs>
                              <linearGradient id={`gradient-${trail.id}`} x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" stopColor="#10b981" />
                                <stop offset="100%" stopColor="#14b8a6" />
                              </linearGradient>
                            </defs>
                          </svg>
                          <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-white">
                            {Math.round(progress)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  </button>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Pro Trails */}
      <div>
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
          <Crown className="h-5 w-5 text-amber-400" />
          Trilhas PRO
        </h2>
        <div className="relative">
          {/* Vertical Connection Line */}
          <div className="absolute left-7 top-8 bottom-8 w-1 rounded-full bg-gradient-to-b from-amber-500/50 via-amber-500/30 to-slate-700" />
          
          <div className="space-y-6">
            {proTrails.map((trail) => (
              <div key={trail.id} className="relative">
                {/* Connection Node */}
                <div className="absolute left-5 top-1/2 z-10 flex h-5 w-5 -translate-y-1/2 items-center justify-center rounded-full border-4 border-amber-500/50 bg-slate-950">
                  <Lock className="h-2.5 w-2.5 text-amber-400" />
                </div>
                
                <button
                  onClick={onProClick}
                  className="ml-12 w-[calc(100%-3rem)] overflow-hidden rounded-2xl border border-amber-500/30 bg-gradient-to-r from-amber-500/5 to-yellow-500/5 p-4 text-left transition-all hover:scale-[1.02] hover:border-amber-500/50"
                >
                  {/* Pro Badge */}
                  <div className="absolute right-4 top-4 rounded-full bg-gradient-to-r from-amber-400 to-yellow-600 px-2 py-0.5 text-xs font-bold text-slate-900">
                    PRO
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${trail.color}`}>
                      <Crown className="h-6 w-6 text-white" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="truncate font-bold text-white">{trail.title}</h3>
                      <p className="truncate text-sm text-slate-400">{trail.description}</p>
                      <div className="mt-2 flex items-center gap-3">
                        <span className="text-xs text-slate-500">{trail.totalLessons} licoes</span>
                        <span className="flex items-center gap-1 text-xs text-amber-400">
                          <Lock className="h-3 w-3" />
                          Desbloqueie
                        </span>
                      </div>
                    </div>
                  </div>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

// Trail Detail View (Duolingo Path Style)
function TrailDetailView({ trail, onBack, onStartLesson, onProClick }: { trail: Trail; onBack: () => void; onStartLesson: (lesson: Lesson) => void; onProClick: () => void }) {
  return (
    <div className="min-h-screen bg-slate-950 pb-28">
      {/* Header */}
      <div className={`bg-gradient-to-br ${trail.color} p-6 pb-24`}>
        <button onClick={onBack} className="mb-4 flex h-10 w-10 items-center justify-center rounded-full bg-white/20 transition-transform hover:scale-110">
          <ChevronLeft className="h-6 w-6 text-white" />
        </button>
        <h1 className="text-2xl font-bold text-white">{trail.title}</h1>
        <p className="mt-1 text-white/80">{trail.description}</p>
        <div className="mt-4 flex items-center gap-3">
          <span className="rounded-full bg-white/20 px-3 py-1 text-sm text-white">{trail.totalLessons} licoes</span>
          <span className="rounded-full bg-white/20 px-3 py-1 text-sm text-white">{trail.completedLessons} completas</span>
        </div>
      </div>

      {/* Lessons Path */}
      <div className="relative -mt-12 px-4">
        {/* Central Path Line */}
        <div className="absolute left-1/2 top-0 -translate-x-1/2 w-1 h-full">
          <div className="h-full w-full rounded-full bg-gradient-to-b from-emerald-500 via-emerald-500/50 to-slate-700" />
        </div>

        <div className="relative space-y-6 py-4">
          {trail.lessons.map((lesson, index) => {
            const isEven = index % 2 === 0
            const canStart = !lesson.isLocked || lesson.isCompleted
            const offsetX = isEven ? -20 : 20

            return (
              <div key={lesson.id} className="relative flex items-center justify-center">
                {/* Connection Node on Center Line */}
                <div 
                  className={`absolute left-1/2 z-20 flex h-8 w-8 -translate-x-1/2 items-center justify-center rounded-full border-4 ${
                    lesson.isCompleted 
                      ? "border-emerald-500 bg-emerald-500" 
                      : lesson.isLocked 
                        ? "border-slate-600 bg-slate-950" 
                        : "border-emerald-500 bg-slate-950"
                  }`}
                >
                  {lesson.isCompleted ? (
                    <CheckCircle2 className="h-4 w-4 text-white" />
                  ) : lesson.isLocked ? (
                    <Lock className="h-3 w-3 text-slate-500" />
                  ) : (
                    <span className="text-xs font-bold text-emerald-400">{index + 1}</span>
                  )}
                </div>

                {/* Horizontal Connection Line */}
                <div 
                  className={`absolute top-1/2 h-0.5 w-8 -translate-y-1/2 ${lesson.isCompleted ? "bg-emerald-500" : "bg-slate-700"}`}
                  style={{ 
                    left: isEven ? "calc(50% - 2rem - 0.5rem)" : "calc(50% + 0.5rem)",
                  }}
                />

                {/* Lesson Card */}
                <button
                  onClick={() => {
                    if (lesson.isPro) onProClick()
                    else if (canStart) onStartLesson(lesson)
                  }}
                  disabled={lesson.isLocked && !lesson.isPro}
                  style={{ transform: `translateX(${offsetX}%)` }}
                  className={`relative w-[75%] max-w-xs overflow-hidden rounded-2xl border p-4 text-left transition-all ${
                    lesson.isCompleted
                      ? "border-emerald-500/50 bg-emerald-500/10"
                      : lesson.isPro
                        ? "border-amber-500/30 bg-amber-500/10 hover:border-amber-500/50"
                        : lesson.isLocked
                          ? "cursor-not-allowed border-slate-800 bg-slate-900/50 opacity-60"
                          : "border-slate-800 bg-slate-900 hover:scale-[1.02] hover:border-emerald-500/50"
                  }`}
                >
                  {/* Pro Badge */}
                  {lesson.isPro && (
                    <div className="absolute right-3 top-3 rounded-full bg-gradient-to-r from-amber-400 to-yellow-600 px-2 py-0.5 text-xs font-bold text-slate-900">
                      PRO
                    </div>
                  )}

                  <div className="flex items-start gap-3">
                    {/* Lesson Icon */}
                    <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl font-bold ${
                      lesson.isCompleted
                        ? "bg-emerald-500 text-white"
                        : lesson.isPro
                          ? "bg-gradient-to-br from-amber-400 to-yellow-600 text-white"
                          : lesson.isLocked
                            ? "bg-slate-800 text-slate-500"
                            : "bg-gradient-to-br from-emerald-500 to-teal-500 text-white"
                    }`}>
                      {lesson.isCompleted ? (
                        <CheckCircle2 className="h-5 w-5" />
                      ) : lesson.isLocked ? (
                        <Lock className="h-4 w-4" />
                      ) : lesson.isPro ? (
                        <Crown className="h-4 w-4" />
                      ) : (
                        <Play className="h-4 w-4" fill="white" />
                      )}
                    </div>

                    {/* Content */}
                    <div className="min-w-0 flex-1">
                      <h3 className="truncate font-semibold text-white">{lesson.title}</h3>
                      <p className="mt-0.5 truncate text-xs text-slate-400">{lesson.description}</p>
                      <div className="mt-2 flex items-center gap-2 text-xs">
                        <span className="text-slate-500">{lesson.duration}</span>
                        <span className="flex items-center gap-1 text-emerald-400">
                          <Zap className="h-3 w-3" />+{lesson.xpReward} XP
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Star Rating (for completed) */}
                  {lesson.isCompleted && (
                    <div className="mt-3 flex items-center justify-center gap-1 rounded-full bg-amber-500/10 py-1">
                      {[1, 2, 3].map((star) => (
                        <Star key={star} className="h-4 w-4 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                  )}
                </button>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// ============================================
// VIEWS: Financial Tools
// ============================================

function ToolsView({ onProClick }: { onProClick: () => void }) {
  const [activeTool, setActiveTool] = useState<string | null>(null)

  const tools = [
    { id: "budget", title: "Controle de Gastos", description: "Organize suas despesas mensais", icon: Wallet, color: "from-emerald-500 to-teal-500", isPro: false },
    { id: "tesouro", title: "Simulador Tesouro Direto", description: "Calcule seus rendimentos", icon: Building2, color: "from-blue-500 to-cyan-500", isPro: false },
    { id: "stocks", title: "Projecao de Acoes", description: "Simule investimentos em acoes", icon: TrendingUp, color: "from-purple-500 to-indigo-500", isPro: false },
    { id: "compound", title: "Juros Compostos", description: "Veja o poder do tempo", icon: Percent, color: "from-amber-500 to-orange-500", isPro: false },
    { id: "emergency", title: "Reserva de Emergencia", description: "Calcule sua reserva ideal", icon: PiggyBank, color: "from-pink-500 to-rose-500", isPro: false },
    { id: "crypto", title: "Simulador Cripto", description: "Projete investimentos em cripto", icon: Coins, color: "from-orange-500 to-red-500", isPro: true },
    { id: "retirement", title: "Aposentadoria", description: "Planeje seu futuro", icon: Target, color: "from-indigo-500 to-purple-500", isPro: true },
  ]

  if (activeTool) {
    const tool = tools.find((t) => t.id === activeTool)
    if (tool) {
      return (
        <ToolDetailView
          toolId={activeTool}
          toolTitle={tool.title}
          onBack={() => setActiveTool(null)}
        />
      )
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-6 pb-28">
      <h1 className="mb-2 text-2xl font-bold text-white">Ferramentas Financeiras</h1>
      <p className="mb-6 text-slate-400">Calcule, simule e planeje seu futuro financeiro</p>

      <div className="grid grid-cols-2 gap-4">
        {tools.map((tool) => {
          const Icon = tool.icon
          return (
            <button
              key={tool.id}
              onClick={() => tool.isPro ? onProClick() : setActiveTool(tool.id)}
              className={`relative overflow-hidden rounded-2xl border p-4 text-left transition-all hover:scale-[1.02] ${
                tool.isPro
                  ? "border-amber-500/30 bg-amber-500/5 hover:border-amber-500/50"
                  : "border-slate-800 bg-slate-900 hover:border-emerald-500/50"
              }`}
            >
              {tool.isPro && (
                <div className="absolute right-2 top-2 rounded-full bg-gradient-to-r from-amber-400 to-yellow-600 px-2 py-0.5 text-xs font-bold text-slate-900">
                  PRO
                </div>
              )}
              <div className={`mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${tool.color}`}>
                <Icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-semibold text-white">{tool.title}</h3>
              <p className="mt-1 text-xs text-slate-400">{tool.description}</p>
            </button>
          )
        })}
      </div>
    </div>
  )
}

// Tool Detail View
function ToolDetailView({ toolId, toolTitle, onBack }: { toolId: string; toolTitle: string; onBack: () => void }) {
  const [values, setValues] = useState<Record<string, number>>({})
  const [result, setResult] = useState<{ value: number; details: string[] } | null>(null)

  const handleCalculate = () => {
    switch (toolId) {
      case "budget": {
        const income = values.income || 0
        const needs = income * 0.5
        const wants = income * 0.3
        const savings = income * 0.2
        setResult({
          value: savings,
          details: [
            `Necessidades (50%): R$ ${needs.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
            `Desejos (30%): R$ ${wants.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
            `Poupanca (20%): R$ ${savings.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
          ],
        })
        break
      }
      case "tesouro": {
        const initial = values.initial || 0
        const monthly = values.monthly || 0
        const years = values.years || 1
        const rate = 0.1 // 10% ao ano
        const months = years * 12
        let total = initial
        for (let i = 0; i < months; i++) {
          total = total * (1 + rate / 12) + monthly
        }
        const totalInvested = initial + monthly * months
        const profit = total - totalInvested
        setResult({
          value: total,
          details: [
            `Total investido: R$ ${totalInvested.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
            `Rendimento: R$ ${profit.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
            `Taxa considerada: 10% a.a.`,
          ],
        })
        break
      }
      case "stocks": {
        const initial = values.initial || 0
        const years = values.years || 1
        const rate = 0.12 // 12% ao ano
        const total = initial * Math.pow(1 + rate, years)
        const profit = total - initial
        setResult({
          value: total,
          details: [
            `Investimento inicial: R$ ${initial.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
            `Valorizacao esperada: R$ ${profit.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
            `Retorno medio historico: 12% a.a.`,
          ],
        })
        break
      }
      case "compound": {
        const initial = values.initial || 0
        const monthly = values.monthly || 0
        const years = values.years || 1
        const rate = (values.rate || 10) / 100
        const months = years * 12
        let total = initial
        for (let i = 0; i < months; i++) {
          total = total * (1 + rate / 12) + monthly
        }
        const totalInvested = initial + monthly * months
        setResult({
          value: total,
          details: [
            `Total investido: R$ ${totalInvested.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
            `Juros acumulados: R$ ${(total - totalInvested).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
            `Taxa: ${(rate * 100).toFixed(1)}% a.a.`,
          ],
        })
        break
      }
      case "emergency": {
        const expenses = values.expenses || 0
        const months = values.months || 6
        const total = expenses * months
        setResult({
          value: total,
          details: [
            `Despesas mensais: R$ ${expenses.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
            `Meses de cobertura: ${months}`,
            `Meta de reserva: R$ ${total.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`,
          ],
        })
        break
      }
      default:
        break
    }
  }

  const getFields = () => {
    switch (toolId) {
      case "budget":
        return [{ id: "income", label: "Renda mensal", placeholder: "5000" }]
      case "tesouro":
      case "compound":
        return [
          { id: "initial", label: "Valor inicial", placeholder: "1000" },
          { id: "monthly", label: "Aporte mensal", placeholder: "500" },
          { id: "years", label: "Anos", placeholder: "5" },
          ...(toolId === "compound" ? [{ id: "rate", label: "Taxa anual (%)", placeholder: "10" }] : []),
        ]
      case "stocks":
        return [
          { id: "initial", label: "Valor inicial", placeholder: "10000" },
          { id: "years", label: "Anos", placeholder: "10" },
        ]
      case "emergency":
        return [
          { id: "expenses", label: "Despesas mensais", placeholder: "3000" },
          { id: "months", label: "Meses de reserva", placeholder: "6" },
        ]
      default:
        return []
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-6 pb-28">
      {/* Header */}
      <div className="mb-6 flex items-center gap-4">
        <button onClick={onBack} className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-900 transition-transform hover:scale-110">
          <ChevronLeft className="h-6 w-6 text-white" />
        </button>
        <h1 className="text-xl font-bold text-white">{toolTitle}</h1>
      </div>

      {/* Input Fields */}
      <div className="space-y-4">
        {getFields().map((field) => (
          <div key={field.id}>
            <label className="mb-2 block text-sm font-medium text-slate-400">{field.label}</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500">R$</span>
              <input
                type="number"
                placeholder={field.placeholder}
                value={values[field.id] || ""}
                onChange={(e) => setValues({ ...values, [field.id]: parseFloat(e.target.value) || 0 })}
                className="w-full rounded-2xl border border-slate-700 bg-slate-900 py-4 pl-12 pr-4 text-lg text-white placeholder-slate-500 outline-none transition-all focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>
          </div>
        ))}
      </div>

      {/* Calculate Button */}
      <Button onClick={handleCalculate} className="mt-6 h-14 w-full rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-lg font-bold text-white transition-all hover:scale-[1.02]">
        <Calculator className="mr-2 h-5 w-5" />
        Calcular
      </Button>

      {/* Result */}
      {result && (
        <div className="mt-6 rounded-3xl border border-emerald-500/30 bg-emerald-500/10 p-6">
          <p className="mb-2 text-sm text-emerald-400">Resultado</p>
          <p className="text-3xl font-bold text-white">
            R$ {result.value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
          </p>
          <div className="mt-4 space-y-2">
            {result.details.map((detail, index) => (
              <div key={index} className="flex items-center gap-2 text-sm text-slate-300">
                <ArrowUpRight className="h-4 w-4 text-emerald-400" />
                <span>{detail}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ============================================
// VIEWS: Video Player
// ============================================

function VideoPlayerView({ lesson, onPractice, onBack }: { lesson: Lesson; onPractice: () => void; onBack: () => void }) {
  const [isLiked, setIsLiked] = useState(false)
  const [isSaved, setIsSaved] = useState(false)

  return (
    <div className="flex min-h-screen flex-col bg-slate-950">
      <div className="relative flex aspect-[9/16] max-h-[85vh] w-full items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
          <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-500">
            <Play className="h-10 w-10 text-white" fill="white" />
          </div>
          <h2 className="mb-2 text-xl font-bold text-white">{lesson.title}</h2>
          <p className="mb-8 text-slate-400">{lesson.description}</p>
          <div className="flex items-center gap-2 rounded-full bg-slate-800/80 px-4 py-2 text-sm text-slate-300">
            <Play className="h-4 w-4" fill="currentColor" />
            <span>Video simulado</span>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-slate-800">
          <div className="h-full w-[65%] bg-gradient-to-r from-emerald-500 to-teal-500" />
        </div>
        <div className="absolute right-4 bottom-20 flex flex-col items-center gap-6">
          <button onClick={() => setIsLiked(!isLiked)} className="flex flex-col items-center gap-1 transition-transform duration-200 hover:scale-110">
            <div className={`flex h-12 w-12 items-center justify-center rounded-full ${isLiked ? "bg-red-500" : "bg-slate-800/80"}`}>
              <Heart className={`h-6 w-6 ${isLiked ? "fill-white text-white" : "text-white"}`} />
            </div>
            <span className="text-xs text-white">2.4k</span>
          </button>
          <button className="flex flex-col items-center gap-1 transition-transform duration-200 hover:scale-110">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-800/80">
              <MessageCircle className="h-6 w-6 text-white" />
            </div>
            <span className="text-xs text-white">128</span>
          </button>
          <button onClick={() => setIsSaved(!isSaved)} className="flex flex-col items-center gap-1 transition-transform duration-200 hover:scale-110">
            <div className={`flex h-12 w-12 items-center justify-center rounded-full ${isSaved ? "bg-emerald-500" : "bg-slate-800/80"}`}>
              <Bookmark className={`h-6 w-6 ${isSaved ? "fill-white text-white" : "text-white"}`} />
            </div>
            <span className="text-xs text-white">Salvar</span>
          </button>
          <button className="flex flex-col items-center gap-1 transition-transform duration-200 hover:scale-110">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-800/80">
              <Share2 className="h-6 w-6 text-white" />
            </div>
            <span className="text-xs text-white">Enviar</span>
          </button>
        </div>
        <button onClick={onBack} className="absolute left-4 top-4 flex h-10 w-10 items-center justify-center rounded-full bg-slate-800/80 transition-transform duration-200 hover:scale-110">
          <ChevronLeft className="h-6 w-6 text-white" />
        </button>
      </div>
      <div className="flex flex-1 items-center justify-center p-4">
        <Button onClick={onPractice} className="h-14 w-full max-w-sm rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-lg font-bold text-white transition-all hover:scale-[1.02]">
          <Sparkles className="mr-2 h-5 w-5" />
          Ir para Pratica
        </Button>
      </div>
    </div>
  )
}

// ============================================
// VIEWS: Quiz
// ============================================

function QuizView({ lesson, onComplete, onBack }: { lesson: Lesson; onComplete: () => void; onBack: () => void }) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [correctCount, setCorrectCount] = useState(0)

  const currentQuestion = mockQuizQuestions[currentIndex]
  const isCorrect = selectedAnswer === currentQuestion?.correctIndex
  const isLastQuestion = currentIndex === mockQuizQuestions.length - 1

  const handleSelect = (index: number) => {
    if (showResult) return
    setSelectedAnswer(index)
    setShowResult(true)
    if (index === currentQuestion.correctIndex) setCorrectCount(correctCount + 1)
  }

  const handleNext = () => {
    if (isLastQuestion) onComplete()
    else {
      setCurrentIndex(currentIndex + 1)
      setSelectedAnswer(null)
      setShowResult(false)
    }
  }

  const progress = ((currentIndex + 1) / mockQuizQuestions.length) * 100

  return (
    <div className="flex min-h-screen flex-col bg-slate-950 px-4 py-6">
      <div className="mb-6">
        <div className="mb-4 flex items-center justify-between">
          <button onClick={onBack} className="flex h-10 w-10 items-center justify-center rounded-full bg-slate-900 transition-transform duration-200 hover:scale-110">
            <ChevronLeft className="h-6 w-6 text-white" />
          </button>
          <span className="text-sm text-slate-400">{currentIndex + 1} de {mockQuizQuestions.length}</span>
          <div className="w-10" />
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-slate-800">
          <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all duration-500" style={{ width: `${progress}%` }} />
        </div>
      </div>

      <div className="flex flex-1 flex-col">
        <div className="mb-6 rounded-3xl border border-slate-800 bg-slate-900 p-6">
          <h2 className="text-xl font-bold text-white">{currentQuestion?.question}</h2>
        </div>

        <div className="space-y-3">
          {currentQuestion?.options.map((option, index) => {
            const isSelected = selectedAnswer === index
            const isCorrectOption = index === currentQuestion.correctIndex

            let cardStyle = "border-slate-700 bg-slate-900 hover:border-emerald-500/50"
            if (showResult) {
              if (isCorrectOption) cardStyle = "border-emerald-500 bg-emerald-500/20"
              else if (isSelected && !isCorrectOption) cardStyle = "border-red-500 bg-red-500/20"
              else cardStyle = "border-slate-700 bg-slate-900 opacity-50"
            } else if (isSelected) {
              cardStyle = "border-emerald-500 bg-emerald-500/20"
            }

            return (
              <button key={index} onClick={() => handleSelect(index)} disabled={showResult} className={`flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition-all duration-200 ${cardStyle}`}>
                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-bold ${
                  showResult && isCorrectOption ? "bg-emerald-500 text-white" : showResult && isSelected && !isCorrectOption ? "bg-red-500 text-white" : "bg-slate-800 text-slate-400"
                }`}>
                  {String.fromCharCode(65 + index)}
                </div>
                <span className="flex-1 font-medium text-white">{option}</span>
                {showResult && isCorrectOption && <CheckCircle2 className="h-6 w-6 text-emerald-400" />}
                {showResult && isSelected && !isCorrectOption && <XCircle className="h-6 w-6 text-red-400" />}
              </button>
            )
          })}
        </div>

        {showResult && (
          <div className={`mt-6 rounded-2xl p-4 ${isCorrect ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
            <p className="text-center font-bold">{isCorrect ? "Mandou bem!" : "Quase la!"}</p>
          </div>
        )}

        {showResult && (
          <Button onClick={handleNext} className="mt-6 h-14 w-full rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-lg font-bold text-white transition-all hover:scale-[1.02]">
            {isLastQuestion ? "Finalizar" : "Proxima"}
            <ChevronRight className="ml-2 h-5 w-5" />
          </Button>
        )}
      </div>

      <div className="mt-6 flex items-center justify-center gap-2 text-sm text-slate-400">
        <Zap className="h-4 w-4 text-emerald-400" />
        <span>+{lesson.xpReward} XP ao completar</span>
      </div>
    </div>
  )
}

// ============================================
// VIEWS: Modals
// ============================================

function ProModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="border-amber-500/30 bg-slate-900 sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600">
            <Crown className="h-8 w-8 text-white" />
          </div>
          <DialogTitle className="text-center text-2xl text-white">Destravar PRO</DialogTitle>
          <DialogDescription className="text-center text-slate-400">Acesse conteudos exclusivos e acelere sua jornada financeira</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-3">
            {["Acesso a todas as aulas avancadas", "Simuladores de investimento", "Suporte prioritario", "Certificados de conclusao"].map((feature, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500/20">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                </div>
                <span className="text-sm text-white">{feature}</span>
              </div>
            ))}
          </div>
          <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 text-center">
            <p className="text-sm text-amber-400">Por apenas</p>
            <p className="text-3xl font-bold text-white">R$ 19,90<span className="text-lg font-normal text-slate-400">/mes</span></p>
          </div>
          <Button className="h-14 w-full rounded-2xl bg-gradient-to-r from-amber-400 to-yellow-600 text-lg font-bold text-slate-900 transition-all hover:scale-[1.02]">
            <Sparkles className="mr-2 h-5 w-5" />
            Quero ser PRO
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function CompletionModal({ isOpen, onClose, xpEarned }: { isOpen: boolean; onClose: () => void; xpEarned: number }) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="border-emerald-500/30 bg-slate-900 sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-500">
            <Trophy className="h-10 w-10 text-white" />
          </div>
          <DialogTitle className="text-center text-2xl text-white">Parabens!</DialogTitle>
          <DialogDescription className="text-center text-slate-400">Voce completou a licao com sucesso!</DialogDescription>
        </DialogHeader>
        <div className="py-4 text-center">
          <div className="inline-flex items-center gap-2 rounded-2xl bg-emerald-500/20 px-6 py-3">
            <Zap className="h-6 w-6 text-emerald-400" />
            <span className="text-2xl font-bold text-emerald-400">+{xpEarned} XP</span>
          </div>
        </div>
        <Button onClick={onClose} className="h-14 w-full rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-lg font-bold text-white transition-all hover:scale-[1.02]">Continuar</Button>
      </DialogContent>
    </Dialog>
  )
}

// ============================================
// VIEWS: Login / Register
// ============================================

function LoginView({ onSuccess }: { onSuccess: () => void }) {
  const [mode, setMode] = useState<"login" | "register">("login")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const { login, register, authEmail } = useAppStore()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Simulate API delay
    await new Promise((r) => setTimeout(r, 800))

    if (mode === "login") {
      if (!authEmail) {
        setError("Nenhuma conta encontrada. Crie uma conta primeiro.")
        setIsLoading(false)
        return
      }
      const success = login(email, password)
      if (success) {
        onSuccess()
      } else {
        setError("Email ou senha incorretos")
      }
    } else {
      if (name.length < 2) {
        setError("Nome deve ter pelo menos 2 caracteres")
        setIsLoading(false)
        return
      }
      if (email.length < 5 || !email.includes("@")) {
        setError("Email invalido")
        setIsLoading(false)
        return
      }
      if (password.length < 6) {
        setError("Senha deve ter pelo menos 6 caracteres")
        setIsLoading(false)
        return
      }
      register(email, password, name)
      onSuccess()
    }
    setIsLoading(false)
  }

  return (
    <div className="flex min-h-screen flex-col bg-background px-4 py-8">
      {/* Logo */}
      <div className="mb-8 flex flex-col items-center">
        <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-primary">
          <Wallet className="h-10 w-10 text-primary-foreground" />
        </div>
        <h1 className="font-display text-3xl font-bold tracking-tight text-foreground">Kapitalia</h1>
        <p className="mt-1 text-muted-foreground">Domine suas financas</p>
      </div>

      {/* Tabs */}
      <div className="mb-6 flex rounded-2xl bg-secondary p-1">
        <button
          onClick={() => setMode("login")}
          className={`flex-1 rounded-xl py-3 text-sm font-medium transition-all ${
            mode === "login" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          Entrar
        </button>
        <button
          onClick={() => setMode("register")}
          className={`flex-1 rounded-xl py-3 text-sm font-medium transition-all ${
            mode === "register" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          Criar Conta
        </button>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {mode === "register" && (
          <div>
            <label className="mb-2 block text-sm font-medium text-muted-foreground">Nome</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Seu nome"
                className="w-full rounded-2xl border border-border bg-card py-4 pl-12 pr-4 text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
          </div>
        )}

        <div>
          <label className="mb-2 block text-sm font-medium text-muted-foreground">Email</label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              className="w-full rounded-2xl border border-border bg-card py-4 pl-12 pr-4 text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20"
            />
          </div>
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium text-muted-foreground">Senha</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Sua senha"
              className="w-full rounded-2xl border border-border bg-card py-4 pl-12 pr-12 text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {error && (
          <div className="rounded-xl bg-destructive/10 p-3 text-center text-sm text-destructive">
            {error}
          </div>
        )}

        <Button
          type="submit"
          disabled={isLoading}
          className="h-14 w-full rounded-2xl bg-primary text-lg font-bold text-primary-foreground transition-all hover:scale-[1.02] hover:opacity-90 disabled:opacity-50"
        >
          {isLoading ? (
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
          ) : mode === "login" ? (
            "Entrar"
          ) : (
            "Criar Conta"
          )}
        </Button>
      </form>

      {/* Demo Notice */}
      <div className="mt-6 rounded-2xl border border-border bg-card/50 p-4 text-center">
        <p className="text-sm text-slate-400">
          Seus dados sao salvos localmente no seu dispositivo.
        </p>
      </div>
    </div>
  )
}

// ============================================
// VIEWS: Profile
// ============================================

function ProfileView({ onLogout, onProClick }: { onLogout: () => void; onProClick: () => void }) {
  const { user, totalXpEarned, completedLessons, watchedVideos, onboardingData, logout } = useAppStore()
  const [showEditModal, setShowEditModal] = useState(false)

  if (!user) return null

  const stats = [
    { icon: Zap, label: "XP Total", value: totalXpEarned, color: "from-emerald-500 to-teal-500" },
    { icon: Trophy, label: "Nivel", value: user.level, color: "from-amber-400 to-yellow-600" },
    { icon: Flame, label: "Streak", value: `${user.streak} dias`, color: "from-orange-500 to-red-500" },
    { icon: CheckCircle2, label: "Licoes", value: completedLessons.size, color: "from-blue-500 to-cyan-500" },
    { icon: Video, label: "Videos", value: watchedVideos.size, color: "from-purple-500 to-indigo-500" },
    { icon: Coins, label: "Moedas", value: user.totalCoins, color: "from-pink-500 to-rose-500" },
  ]

  const handleLogout = () => {
    logout()
    onLogout()
  }

  return (
    <div className="min-h-screen bg-slate-950 px-4 py-6 pb-28">
      {/* Profile Header */}
      <div className="mb-6 flex flex-col items-center">
        <div className="relative mb-4">
          <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 text-3xl font-bold text-white ring-4 ring-emerald-500/20">
            {user.name.charAt(0).toUpperCase()}
          </div>
          {user.isPro && (
            <div className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-yellow-600 ring-2 ring-slate-950">
              <Crown className="h-4 w-4 text-white" />
            </div>
          )}
        </div>
        <h1 className="text-2xl font-bold text-white">{user.name}</h1>
        {user.email && <p className="mt-1 text-slate-400">{user.email}</p>}
        <div className="mt-2 flex items-center gap-2">
          <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-sm font-medium text-emerald-400">
            Nivel {user.level}
          </span>
          {user.isPro && (
            <span className="rounded-full bg-gradient-to-r from-amber-400 to-yellow-600 px-3 py-1 text-sm font-bold text-slate-900">
              PRO
            </span>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="mb-6 grid grid-cols-3 gap-3">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <div key={stat.label} className="rounded-2xl border border-slate-800 bg-slate-900 p-3 text-center">
              <div className={`mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${stat.color}`}>
                <Icon className="h-5 w-5 text-white" />
              </div>
              <p className="text-lg font-bold text-white">{stat.value}</p>
              <p className="text-xs text-slate-400">{stat.label}</p>
            </div>
          )
        })}
      </div>

      {/* XP Progress */}
      <div className="mb-6 rounded-3xl border border-slate-800 bg-slate-900 p-5">
        <div className="mb-3 flex items-center justify-between">
          <span className="text-sm font-medium text-slate-400">Progresso Nivel {user.level + 1}</span>
          <span className="text-sm font-bold text-emerald-400">{user.xp}/{user.xpToNextLevel} XP</span>
        </div>
        <div className="h-3 overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all"
            style={{ width: `${(user.xp / user.xpToNextLevel) * 100}%` }}
          />
        </div>
      </div>

      {/* Onboarding Info */}
      {onboardingData && (
        <div className="mb-6 rounded-3xl border border-slate-800 bg-slate-900 p-5">
          <h3 className="mb-4 flex items-center gap-2 font-semibold text-white">
            <Target className="h-5 w-5 text-emerald-400" />
            Seu Perfil
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Faixa etaria</span>
              <span className="text-sm font-medium text-white">{onboardingData.age} anos</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Objetivo</span>
              <span className="text-sm font-medium text-white capitalize">
                {onboardingData.goal.replace("_", " ")}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Experiencia</span>
              <span className="text-sm font-medium text-white capitalize">{onboardingData.experience}</span>
            </div>
          </div>
        </div>
      )}

      {/* Join Date */}
      {user.joinedAt && (
        <div className="mb-6 flex items-center justify-center gap-2 text-sm text-slate-400">
          <Calendar className="h-4 w-4" />
          <span>
            Membro desde {new Date(user.joinedAt).toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
          </span>
        </div>
      )}

      {/* Actions */}
      <div className="space-y-3">
        {!user.isPro && (
          <button
            onClick={onProClick}
            className="flex w-full items-center justify-between rounded-2xl border border-amber-500/30 bg-gradient-to-r from-amber-500/10 to-yellow-500/10 p-4 transition-all hover:scale-[1.02]"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400 to-yellow-600">
                <Crown className="h-5 w-5 text-white" />
              </div>
              <div className="text-left">
                <p className="font-semibold text-white">Seja PRO</p>
                <p className="text-xs text-slate-400">Desbloqueie todo o conteudo</p>
              </div>
            </div>
            <ChevronRight className="h-5 w-5 text-amber-400" />
          </button>
        )}

        <button
          onClick={handleLogout}
          className="flex w-full items-center justify-between rounded-2xl border border-slate-800 bg-slate-900 p-4 transition-all hover:border-red-500/30 hover:bg-red-500/10"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-500/20">
              <LogOut className="h-5 w-5 text-red-400" />
            </div>
            <span className="font-semibold text-white">Sair da Conta</span>
          </div>
          <ChevronRight className="h-5 w-5 text-slate-400" />
        </button>
      </div>
    </div>
  )
}

// ============================================
// MAIN: App
// ============================================

type AppView = "login" | "onboarding" | "main" | "video" | "quiz"

function FinanceApp() {
  const [currentView, setCurrentView] = useState<AppView>("login")
  const [activeTab, setActiveTab] = useState<TabType>("home")
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null)
  const [showProModal, setShowProModal] = useState(false)
  const [showCompletionModal, setShowCompletionModal] = useState(false)
  const [isHydrated, setIsHydrated] = useState(false)

  // Zustand store
  const {
    isLoggedIn,
    isOnboarded,
    user,
    completeOnboarding,
    completeLesson,
    updateStreak,
    isLessonCompleted,
  } = useAppStore()

  const { data, isLoading, refetch } = useDashboardViewModel()

  // Hydration check for SSR
  useEffect(() => {
    setIsHydrated(true)
  }, [])

  // Set initial view based on persisted state
  useEffect(() => {
    if (isHydrated) {
      if (isLoggedIn && isOnboarded) {
        setCurrentView("main")
        updateStreak() // Update streak on app open
      } else if (isLoggedIn && !isOnboarded) {
        setCurrentView("onboarding")
      } else {
        setCurrentView("login")
      }
    }
  }, [isHydrated, isLoggedIn, isOnboarded, updateStreak])

  const handleOnboardingComplete = () => {
    setCurrentView("main")
  }

  // Custom onboarding that saves to Zustand
  const handleOnboardingSubmit = (onboardingData: OnboardingData) => {
    completeOnboarding(onboardingData)
    setCurrentView("main")
  }

  const handleStartLesson = (lesson: Lesson) => {
    setSelectedLesson(lesson)
    setCurrentView("video")
  }

  const handlePractice = () => setCurrentView("quiz")

  const handleQuizComplete = () => {
    if (selectedLesson) {
      // Save lesson completion to Zustand
      completeLesson(selectedLesson.id, selectedLesson.xpReward)
    }
    setShowCompletionModal(true)
  }

  const handleCompletionClose = () => {
    setShowCompletionModal(false)
    setSelectedLesson(null)
    setCurrentView("main")
    refetch()
  }

  const handleBackToMain = () => {
    setSelectedLesson(null)
    setCurrentView("main")
  }

  // Show loading while hydrating
  if (!isHydrated) {
    return <DashboardSkeleton />
  }

  if (currentView === "login" && !isLoggedIn) {
    return <LoginView onSuccess={() => setCurrentView(isOnboarded ? "main" : "onboarding")} />
  }

  if (currentView === "onboarding" && !isOnboarded) {
    return <OnboardingView onComplete={handleOnboardingComplete} onSubmit={handleOnboardingSubmit} />
  }

  if (currentView === "video" && selectedLesson) {
    return <VideoPlayerView lesson={selectedLesson} onPractice={handlePractice} onBack={handleBackToMain} />
  }

  if (currentView === "quiz" && selectedLesson) {
    return (
      <>
        <QuizView lesson={selectedLesson} onComplete={handleQuizComplete} onBack={() => setCurrentView("video")} />
        <CompletionModal isOpen={showCompletionModal} onClose={handleCompletionClose} xpEarned={selectedLesson.xpReward} />
      </>
    )
  }

  if (isLoading || !data) {
    return <DashboardSkeleton />
  }

  // Merge persisted user data with fetched data
  const mergedData = {
    ...data,
    user: user || data.user,
    trails: data.trails.map(trail => ({
      ...trail,
      lessons: trail.lessons.map(lesson => ({
        ...lesson,
        isCompleted: isLessonCompleted(lesson.id) || lesson.isCompleted,
      })),
      completedLessons: trail.lessons.filter(l => isLessonCompleted(l.id) || l.isCompleted).length,
    })),
  }

  return (
    <>
      {activeTab === "home" && <HomeView data={mergedData} onStartLesson={handleStartLesson} onProClick={() => setShowProModal(true)} />}
      {activeTab === "videos" && <VideoFeed videos={data.videos} onProClick={() => setShowProModal(true)} />}
      {activeTab === "trails" && <TrailsView trails={mergedData.trails} onStartLesson={handleStartLesson} onProClick={() => setShowProModal(true)} />}
      {activeTab === "tools" && <ToolsView onProClick={() => setShowProModal(true)} />}
      {activeTab === "profile" && <ProfileView onLogout={() => setCurrentView("login")} onProClick={() => setShowProModal(true)} />}
      
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
      <ProModal isOpen={showProModal} onClose={() => setShowProModal(false)} />
    </>
  )
}

// ============================================
// PROVIDER
// ============================================

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
})

export default function Page() {
  return (
    <QueryClientProvider client={queryClient}>
      <FinanceApp />
    </QueryClientProvider>
  )
}
